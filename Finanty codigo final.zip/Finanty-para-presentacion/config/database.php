<?php
// config/database.php
require_once __DIR__ . '/session.php';

class Database {
    private $host;
    private $port;
    private $db_name;
    private $username;
    private $password;
    private $charset = "utf8mb4";
    private $conn;

    public function __construct() {
        $this->host = getenv('FINANTY_DB_HOST') ?: '127.0.0.1';
        $this->port = getenv('FINANTY_DB_PORT') ?: '3306';
        $this->db_name = getenv('FINANTY_DB_NAME') ?: 'finanty_db';
        $this->username = getenv('FINANTY_DB_USER') ?: 'root';
        $this->password = getenv('FINANTY_DB_PASSWORD') ?: '';
    }

    public function getConnection() {
        $this->conn = null;
        try {
            $dsn = "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name . ";charset=" . $this->charset;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        } catch (PDOException $exception) {
            error_log("Error de conexión: " . $exception->getMessage());
            http_response_code(500);
            $message = 'No se pudo conectar con MySQL. Iniciá MySQL en XAMPP y verificá que exista la base finanty_db.';
            if (strpos($exception->getMessage(), 'Unknown database') !== false) {
                $message = 'No existe la base finanty_db en esta computadora. Importá database/finanty_db.sql desde phpMyAdmin.';
            }
            echo json_encode(["status" => "error", "mensaje" => $message], JSON_UNESCAPED_UNICODE);
            exit;
        }
        return $this->conn;
    }
}

$database = new Database();
$pdo = $database->getConnection();
